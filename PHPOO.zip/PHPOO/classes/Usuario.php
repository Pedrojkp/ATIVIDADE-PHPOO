<?php

class Usuario
{

    // Encapsulamento
    private $email;
    private $senha;

    // Construtor
    public function __construct($email, $senha)
    {
        $this->setEmail($email);
        $this->setSenha($senha);
    }

    // Setter Email
    public function setEmail($email)
    {

        if (empty($email)) {
            throw new Exception("O e-mail é obrigatório!");
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("E-mail inválido!");
        }

        $this->email = $email;
    }

    // Setter Senha
    public function setSenha($senha)
    {

        if (empty($senha)) {
            throw new Exception("A senha é obrigatória!");
        }

        if (strlen($senha) < 6) {
            throw new Exception("A senha deve ter no mínimo 6 caracteres!");
        }

        $this->senha = $senha;
    }

    // Getters
    public function getEmail()
    {
        return $this->email;
    }

    public function getSenha()
    {
        return $this->senha;
    }
}
