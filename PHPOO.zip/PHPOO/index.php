<?php
session_start();

if (isset($_SESSION['usuario'])) {
    header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>TechSolutions</title>

    <link rel="stylesheet" href="css/style.css">

    <!-- Font Awesome -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>

    <div class="container">

        <div class="card animacao">

            <h1>
                <i class="fa-solid fa-headset"></i>
                TechSolutions
            </h1>

            <p>Sistema de Gerenciamento de Chamados</p>

            <a href="login.php" class="btn">
                <i class="fa-solid fa-right-to-bracket"></i>
                Entrar
            </a>

        </div>

    </div>

</body>

</html>