<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$mensagem = "";

$chamados = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $titulo = $_POST['titulo'];
    $descricao = $_POST['descricao'];

    if (empty($titulo) || empty($descricao)) {

        $mensagem = "Preencha todos os campos!";
    } else {

        $chamados[] = [
            "titulo" => $titulo,
            "descricao" => $descricao
        ];

        $mensagem = "Chamado cadastrado com sucesso!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">

    <title>Dashboard</title>

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>

    <div class="container">

        <div class="card animacao">

            <h2>
                <i class="fa-solid fa-gauge"></i>
                Dashboard
            </h2>

            <p>
                Bem-vindo,
                <strong><?php echo $_SESSION['usuario']; ?></strong>
            </p>

            <a href="logout.php" class="btn-sair">
                <i class="fa-solid fa-right-from-bracket"></i>
                Sair
            </a>

            <hr>

            <?php if (!empty($mensagem)) { ?>

                <div class="sucesso">
                    <?php echo $mensagem; ?>
                </div>

            <?php } ?>

            <form method="POST">

                <input type="text"
                    name="titulo"
                    placeholder="Título do chamado">

                <textarea
                    name="descricao"
                    placeholder="Descrição do problema"></textarea>

                <button type="submit" class="btn">
                    Abrir Chamado
                </button>

            </form>

        </div>

    </div>

</body>

</html>