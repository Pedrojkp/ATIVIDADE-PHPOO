<?php
session_start();

require_once 'classes/Usuario.php';

$mensagem = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    try {

        $email = $_POST['email'];
        $senha = $_POST['senha'];

        $usuario = new Usuario($email, $senha);

        // Login fictício
        if (
            $usuario->getEmail() == "admin@tech.com" &&
            $usuario->getSenha() == "123456"
        ) {

            $_SESSION['usuario'] = $usuario->getEmail();

            header("Location: dashboard.php");
            exit();
        } else {
            $mensagem = "E-mail ou senha inválidos!";
        }
    } catch (Exception $e) {
        $mensagem = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">

    <title>Login</title>

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>

    <div class="container">

        <form method="POST" class="card animacao">

            <h2>
                <i class="fa-solid fa-user"></i>
                Login
            </h2>

            <?php if (!empty($mensagem)) { ?>

                <div class="erro">
                    <?php echo $mensagem; ?>
                </div>

            <?php } ?>

            <input type="email"
                name="email"
                placeholder="Digite seu e-mail"
                required>

            <input type="password"
                name="senha"
                placeholder="Digite sua senha"
                required>

            <button type="submit" class="btn">
                Entrar
            </button>

        </form>

    </div>

</body>

</html>